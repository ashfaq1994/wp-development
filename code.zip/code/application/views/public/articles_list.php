<?php include('public_header.php'); ?>
<div class="section___form">
			<div class="container">
				<div class="row">
					<!--- coloumn -->
					<div class="col-md-6">
						<div class="form__heading mt-5">
							<h2 class="display-4 text-uppercase bg-faded">
							Register
							</h2>
							<form action="#">
								<div class="form-group">
									<label for="name">Name</label>
									<input type="text" name="name" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Enter email">
								</div>
								<div class="form-group">
									<label for="email">Email address</label>
									<input type="namew" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
								</div>
								<div class="form-group">
									<label for="password">Password</label>
									<input type="password" class="form-control" id="password" aria-describedby="emailHelp" placeholder="Enter email">
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
								</div>
								<div class="form-group">
									<label for="password1">Confirm Password</label>
									<input type="password" class="form-control" id="password1" aria-describedby="emailHelp" placeholder="Enter email">
								</div>
								<div class="form-group">
									<button class="btn btn-info" type="submit">SUBMIT</button>
								</div>
							</form>
						</div>
					</div>					
 <!--- coloum end -->
					<div class="col-md-6">
						<div class="form__heading mt-5">
							<h2 class="display-4 text-uppercase bg-faded">
							Sign-in
							</h2>
							<form action="#">
								<div class="form-group">
									<label for="email1">Email address</label>
									<input type="namew" class="form-control" id="email1" aria-describedby="emailHelp" placeholder="Enter email">
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
								</div>
								<div class="form-group">
									<label for="password1">Password</label>
									<input type="password" class="form-control" id="password1" aria-describedby="emailHelp" placeholder="Enter email">
									<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
								</div>
								<div class="form-group">
									<button class="btn btn-info" type="submit">SUBMIT</button>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
		</div>
<?php include('public_footer.php') ?>