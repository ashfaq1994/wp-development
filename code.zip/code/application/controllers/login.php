<?php


class login extends MY_Controller
{
	public function index()

	{
		$this->load->helper('form','url');

		$this->load->view('public/admin_login');
	}


	public function admin_login()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_error_delimiters('<p class="text-danger">', '</p>');
		$this->form_validation->set_rules(
			'username', 
			'Username', 
			'trim|required|min_length[5]|max_length[12]'
		);

        $this->form_validation->set_rules(
        	'password', 
        	'Password', 
        	'trim|required|min_length[8]'
        );

		if ($this->form_validation->run()) {

            $username = $this->input->post('username');
            $password = $this->input->post('password');
            $this->load->model('loginmodel');
			if($this->loginmodel->login_valid($username,$password))
			{

			}
			else
			{
				
			}
		}
		else
		{
			$this->load->view('public/admin_login');
		}
	}
}
