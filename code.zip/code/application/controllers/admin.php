<?php

class Admin extends MY_Controller
{
	public function index()
	{
		echo "index";
	}
}
