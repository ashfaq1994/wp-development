<?php

class LoginModel extends CI_Model
{
	public function login_valid($username,$password)
	{
		$this->db->where(array(
			'username'=>$username,
			'password'=>$password
		));
         return true;	
	}
}